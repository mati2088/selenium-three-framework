package com.selenium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneSeleniumApplicationTests {

	@Test
	void contextLoads() {
	}

}
